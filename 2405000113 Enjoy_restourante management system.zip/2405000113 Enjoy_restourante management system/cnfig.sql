-- create user
create database Enjoy_restourante;
create user  'izere'@'127.0.0.1' identified by '2405000113';
grant all privileges on Enjoy_restourante .* to 'izere'@'127.0.0.1';
flush privileges;