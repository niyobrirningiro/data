show databases;
use enjoy_restourante;
-- create customers table
create table Customers(customer_id  int primary key,
             firstname varchar(100),
             lastname varchar(100),
             email varchar(100),
             phone int);

use enjoy_restourante;
-- insert data into customers 
  
  insert into customers(customer_id,firstname,lastname,email,phone ) values
  (1,'annet','muhoza','muhoza@gmail.com','07823456');
   insert into customers(customer_id,firstname,lastname,email,phone ) values
  (4,'derick','mugabo','mugabo@gmail.com','0780876'),
  (5,'herve','uwase','uwase@gmail.com','0781234'),
  (6,'dennis','kelly','kelly@gmail.com','0734543');
  -- insert data in customer using restored procedure
  delimiter $$
 CREATE PROCEDURE insertcustomers(in customer_idparam int,
                                   in firstnameparam varchar(100),
								   in lastnameparam varchar(100),
                                   in emailparam varchar(100),
								   in phoneparam int)
         BEGIN
         
insert into customers values (customer_idparam ,firstnameparam ,lastnameparam ,emailparam ,phoneparam );       
         END $$
    delimiter ;
    call insertcustomers(2,'pacifique','muhire','muhire@gmail.com',0787654);
    call insertcustomers(3,'Amani','ruferedi','amani@gmail.com',07812344);
    -- count all customers in table
select count(customer_id)from customers;
-- create name of customer view
create view customernames as
select firstname,lastname from customers;
select* from customernames;

-- create menutable
create table Menu(menu_id  int primary key,
             item_name varchar (100),
             Description  varchar(150),
             price int);
             
-- insert data in menu table
             
insert into Menu( menu_id,item_name,Description,price)values
                (1,'fanta','non alcholic drink',1000); 
insert into Menu( menu_id,item_name,Description,price)values
                (4,'bananajuice','non alcholic drink',1200),
                (5,'milk','non alcholic drink',3000),
                (6,'bread','maize proct',500); 
                
-- insert data in menu table usin restored procedure
                
                delimiter $$
 CREATE PROCEDURE insertmnu(in menu_idparam int,
                                   in item_nameparam varchar(100),
								   in descriptionparam varchar(150),
								   in priceparam int)
         BEGIN
         
insert into Menu values (menu_idparam ,item_nameparam ,descriptionparam ,priceparam);       
         END $$
    delimiter ;
    call insertmnu (2,'banana','fruits',200);
    call insertmnu (3,'pinapple','fruits',100);
    
    -- count product in menu table
    select count(menu_id)from Menu;
    -- view the addition of price in menu table 
    select sum(price) from Menu;
    -- get average of price for produvt
    select avg(price)from Menu;
    -- show view of fooddetails 
    create view fooddetails as
    select item_name,description,price from Menu;
    select * from fooddetails;
    -- update description from maize prduct to maize product
    update Menu set description='maize product'
     where menu_id='6';
    -- create table employees
create table Employees(emp_id int primary key,
			firstname varchar(100),
            lastname varchar(100),
            position varchar(100),
            salary int);
            -- insert data into employee table
 
 insert into Employees(emp_id ,firstname ,lastname,position ,salary ) values
                      (01,'jean','mwema','manager',500000),
                      (02,'emmy','niyigena','director',600000),
                      (03,'ange','teta','customer_care',300000)
                      ;
                     
-- insert data into employee table using stored procedures
                      delimiter $$
 CREATE PROCEDURE insertemp(in emp_idparam int,
                                   in firstnameparam varchar(100),
								   in lastnameparam varchar(150),
								   in positionparam  varchar (100),
								   in salaryparam  int)
                                   
         BEGIN
         
insert into employees values (emp_idparam ,firstnameparam ,lastnameparam ,positionparam,salaryparam);       
         END $$
    delimiter ;
    call insertemp (4,'evode','kalisa','head_cleaner',200000);
    call insertemp (5,'carine','ishimwe','cleaner',100000);
    call insertemp (6,'Divine','karabo','cleaner',100000);
    call insertemp (7,'aline','uwase','waiter',250000);
    call insertemp (8,'david','molise','waiter',250000);
    -- count the number of employes
     select count(emp_id)from employees;
     -- the total amount of salary to all employees
    select sum(salary) from employees;
    -- the average of salary to every employee
    select avg(salary)from employees;
    -- show all cleaners in employees table
    create view cleaners as
    select emp_id ,firstname ,lastname,salary  from employees where position='cleaner';
    select * from cleaners;
    
    -- show employees get salary more than 300000
    create view low_salary as
    select * from employees where salary <300000;
    select * from low_salary;
    
            
create table Orders(order_id int primary key,
					order_date  date,
                    time varchar(10),
                    total_amount int,
                    customer_id int,
                    foreign key(customer_id) references Customers(customer_id));
                    
                    alter table orders add column menu_id int;
                    
                    alter table orders add column emp_id int;
                    
                    
   alter table orders 
   add constraint menu_id foreign key(menu_id)references Menu (menu_id);
      alter table orders 
   add constraint emp_id foreign key(emp_id)references Employees (emp_id);
   
   -- insert data in orders table
   insert into orders(order_id ,order_date ,time,total_amount,customer_id,menu_id,emp_id) values
                      (1,'2025-01-01','10:01',5000,2,3,1);
insert into orders(order_id ,order_date ,time,total_amount,customer_id,menu_id,emp_id) values
                      (2,'2025-01-02','11:01',5000,1,1,7),
                      (3,'2024-12-02','1:01',10000,3,2,7),
                      (4,'2025-01-05','03:40',3000,4,4,8)
                      ;
 select *  from orders;
 -- insert data into employee table using stored procedures
                      delimiter $$
 CREATE PROCEDURE insert_order(in order_idparam int,
                                   in order_dateparam  date,
								   in timeparam varchar(10),
                                   in total_amountparam int,
								   in customer_idparam  int,
								   in menu_idparam  int,
								   in emp_idparam  int)
                                   
         BEGIN
         
insert into orders values (order_idparam ,order_dateparam,timeparam,total_amountparam,customer_idparam,menu_idparam,emp_idparam);       
         END $$
    delimiter ;
    call insert_order(5,'2025-01-05','04:40',7000,5,5,8);
    call insert_order(6,'2025-01-07','07:40',20000,6,6,7);
    call insert_order(7,'2025-01-07','08:40',10000,3,1,8);
    call insert_order(8,'2025-01-07','10:15',5000,1,5,7);
    select*  from orders;
    select count(order_id) from orders;
    

 
 
                      
                   
